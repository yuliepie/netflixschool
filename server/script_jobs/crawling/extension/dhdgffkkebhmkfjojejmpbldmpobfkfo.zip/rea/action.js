'use strict';(()=>{})(rea);
